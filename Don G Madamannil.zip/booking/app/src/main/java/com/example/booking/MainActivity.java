package com.example.booking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    FragmentManager fragmentManager=getSupportFragmentManager();
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            Button bk=(Button) findViewById(R.id.b1);
            Button bkn;
            bk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerView,bkingdn.class, null)
                            .setReorderingAllowed(true)
                            .addToBackStack("name")
                            .commit();
                }

            });
/*
            bkn=(Button) findViewById(R.id.regbtn);

            bkn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getApplicationContext(), "Booking Successful", Toast.LENGTH_LONG).show();
                }
            });
*/

            Button dis=findViewById(R.id.b2);
            dis.setOnClickListener(new View.OnClickListener()
            {
                public void onClick(View view)
                {

                    fragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerView ,displaydn.class , null)
                            .setReorderingAllowed(true)
                            .addToBackStack("name")
                            .commit();
                }
            });



        }
}